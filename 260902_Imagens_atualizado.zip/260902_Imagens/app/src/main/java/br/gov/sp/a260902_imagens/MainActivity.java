package br.gov.sp.a260902_imagens;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.switchmaterial.SwitchMaterial;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ImageView imgPadrao;
    private ImageView imgPapel;
    private ImageView imgTesoura;
    private ImageView imgPedra;

    private TextView txtResultado;

    // Placar geral (acumulado entre o Usuário e o PC)
    private TextView txtPlacarUsuario;
    private TextView txtPlacarPc;
    private int placarUsuario = 0;
    private int placarPc = 0;

    // Botão para limpar o resultado da rodada
    private Button btnLimpar;

    // Modo Melhor de 3
    private SwitchMaterial switchMelhorDe3;
    private TextView txtPartida;
    private boolean modoMelhorDe3 = false;
    private int vitoriasUsuarioPartida = 0;
    private int vitoriasPcPartida = 0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);


        //Instaciando os componentes da interface

        imgPadrao = findViewById(R.id.imgPadrao);
        imgPapel = findViewById(R.id.imgPapel);
        imgPedra = findViewById(R.id.imgPedra);
        imgTesoura = findViewById(R.id.imgTesoura);
        txtResultado = findViewById(R.id.txtResultado);

        txtPlacarUsuario = findViewById(R.id.txtPlacarUsuario);
        txtPlacarPc = findViewById(R.id.txtPlacarPc);
        btnLimpar = findViewById(R.id.btnLimpar);
        switchMelhorDe3 = findViewById(R.id.switchMelhorDe3);
        txtPartida = findViewById(R.id.txtPartida);


        //clique tesoura
        imgTesoura.setOnClickListener(view -> {
            opcSelecionada("tesoura");
        });

        //clique pedra
        imgPedra.setOnClickListener(view -> {
            opcSelecionada("pedra");
        });

        //clique papel
        imgPapel.setOnClickListener(view -> {
            opcSelecionada("papel");
        });

        //clique no botão de limpar o resultado
        btnLimpar.setOnClickListener(view -> {
            limparResultado();
        });

        //liga/desliga o modo Melhor de 3
        switchMelhorDe3.setOnCheckedChangeListener((buttonView, isChecked) -> {
            modoMelhorDe3 = isChecked;
            vitoriasUsuarioPartida = 0;
            vitoriasPcPartida = 0;

            if (modoMelhorDe3) {
                txtPartida.setVisibility(View.VISIBLE);
                atualizaTxtPartida();
            } else {
                txtPartida.setVisibility(View.GONE);
            }
        });

    }

    public void opcSelecionada(String opcaoSelecionada){
        // escolha aleatoria dp pc:
        int numero = new Random().nextInt(3);
        String[] opcoes = {"pedra" , "papel" , "tesoura"};
        String opcPC = opcoes[numero];

        // apresentando a imagem correspondente no pc
        switch (opcPC) {
            case "pedra":
                imgPadrao.setImageResource(R.drawable.pedra);
                break;
            case "papel":
                imgPadrao.setImageResource(R.drawable.papel);
                break;
            case "tesoura":
                imgPadrao.setImageResource(R.drawable.tesoura);
                break;
        }

        // Verifica o vencedor
        if(
                // pc ganhando
                (opcPC.equals("tesoura") && opcaoSelecionada.equals("papel")) ||
                (opcPC.equals("papel") && opcaoSelecionada.equals("pedra")) ||
                (opcPC.equals("pedra") && opcaoSelecionada.equals("tesoura"))

        ){
            txtResultado.setText("Perdeu");
            placarPc++;
            if (modoMelhorDe3) {
                vitoriasPcPartida++;
            }
        }else if (
                // jogador ganhando
                (opcaoSelecionada.equals("tesoura") && opcPC.equals("papel")) ||
                (opcaoSelecionada.equals("papel") && opcPC.equals("pedra")) ||
                (opcaoSelecionada.equals("pedra") && opcPC.equals("tesoura"))
        ){
            txtResultado.setText("Ganhou");
            placarUsuario++;
            if (modoMelhorDe3) {
                vitoriasUsuarioPartida++;
            }
        } else{
            txtResultado.setText("empatou");
        }

        atualizaPlacar();

        if (modoMelhorDe3) {
            atualizaTxtPartida();
            verificaFimDaPartida();
        }
    }

    // Atualiza os textos do placar geral (Usuário x PC)
    private void atualizaPlacar(){
        txtPlacarUsuario.setText("Usuário: " + placarUsuario);
        txtPlacarPc.setText("PC: " + placarPc);
    }

    // Atualiza o texto com o placar da partida atual no modo Melhor de 3
    private void atualizaTxtPartida(){
        txtPartida.setText("Partida (Melhor de 3): " + vitoriasUsuarioPartida + " x " + vitoriasPcPartida);
    }

    // Verifica se algum dos lados já alcançou 2 vitórias na partida (Melhor de 3)
    private void verificaFimDaPartida(){
        if (vitoriasUsuarioPartida == 2 || vitoriasPcPartida == 2){
            String vencedor = (vitoriasUsuarioPartida == 2) ? "Usuário" : "PC";

            new AlertDialog.Builder(this)
                    .setTitle("Fim de partida")
                    .setMessage("Vencedor da partida (Melhor de 3): " + vencedor + "!\n\nToque em OK para iniciar uma nova partida.")
                    .setCancelable(false)
                    .setPositiveButton("OK", (dialog, which) -> {
                        vitoriasUsuarioPartida = 0;
                        vitoriasPcPartida = 0;
                        atualizaTxtPartida();
                    })
                    .show();
        }
    }

    // Limpa o resultado da rodada, a escolha do PC e a mensagem exibida.
    // O placar geral (Usuário x PC) é mantido, servindo apenas para preparar a tela para uma nova jogada.
    private void limparResultado(){
        txtResultado.setText("clique na opção desejada");
        imgPadrao.setImageResource(R.drawable.padrao);
    }
}