package br.gov.sp.a260902_imagens;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ImageView imgPadrao;
    private ImageView imgPapel;
    private ImageView imgTesoura;
    private ImageView imgPedra;

    private TextView txtResultado;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);


        //Instaciando os componentes da interface

        imgPadrao = findViewById(R.id.imgPadrao);
        imgPapel = findViewById(R.id.imgPapel);
        imgPedra = findViewById(R.id.imgPedra);
        imgTesoura = findViewById(R.id.imgTesoura);
        txtResultado = findViewById(R.id.txtResultado);


        //clique tesoura
        imgTesoura.setOnClickListener(view -> {
            opcSelecionada("tesoura");
        });

        //clique pedra
        imgPedra.setOnClickListener(view -> {
            opcSelecionada("pedra");
        });

        //clique papel
        imgPapel.setOnClickListener(view -> {
            opcSelecionada("papel");
        });

    }

    public void opcSelecionada(String opcaoSelecionada){
        // escolha aleatoria dp pc:
        int numero = new Random().nextInt(3);
        String[] opcoes = {"pedra" , "Papel" , "tesoura"};
        String opcPC = opcoes[numero];

        // apresentando a imagem correspondente no pc
        switch (opcPC) {
            case "pedra":
                imgPadrao.setImageResource(R.drawable.pedra);
                break;
            case "papel":
                imgPadrao.setImageResource(R.drawable.papel);
                break;
            case "tesoura":
                imgPadrao.setImageResource(R.drawable.tesoura);
                break;
        }

        // Verifica o vencedor
        if(
                // pc ganhando
                (opcPC.equals("tesoura") && opcaoSelecionada.equals("papel")) ||
                (opcPC.equals("papel") && opcaoSelecionada.equals("pedra")) ||
                (opcPC.equals("pedra") && opcaoSelecionada.equals("tesoura"))

        ){
            txtResultado.setText("Perdeu");
        }else if (
                // jogador ganhando
                (opcaoSelecionada.equals("tesoura") && opcPC.equals("papel")) ||
                (opcaoSelecionada.equals("papel") && opcPC.equals("pedra")) ||
                (opcaoSelecionada.equals("pedra") && opcPC.equals("tesoura"))
        ){
            txtResultado.setText("Ganhou");
        } else{
            txtResultado.setText("empatou");
        }

    }
}